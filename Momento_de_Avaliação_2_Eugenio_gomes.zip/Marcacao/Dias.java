class Dias
{
    Marcacao instanciaDias;
    String incSab;
    String sSab;
    static String[] arrayDiasIncSabado = {"Segunda-feira", "Terça- Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-feira", "Sábado"};
    static String[] arraydiasExcSabado = {"Segunda-feira", "Terça- Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-feira"};
    static String[] arrayHorarios = {"9:00", "10:00", "11:00", "14:00", "15:00", "16:00"};
    Dias(String paramIncSab, String paramTodos)
    {
        incSab = paramIncSab;
        sSab = paramTodos;
    }
    
    
}