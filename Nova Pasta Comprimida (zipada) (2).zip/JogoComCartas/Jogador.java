import java.util.ArrayList;
//Subclasse de jogador
//Extends é uma keyword que implementa o conceito de herança(inhertance)

class Jogador extends Utilizador
{
   int pontos;
   String nomeNoJogo;
   Carta cartaDoJogador;
   ArrayList<Carta> maoJogador;
   Jogador()
   {
       
   }
   
   void comprarCarta()
   {
       
   }
   
   void descartarCarta()
   {
       
   }
   
   void mostrarCarta()
   {
       
   }
}
